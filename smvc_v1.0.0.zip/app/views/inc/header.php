<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?= SITENAME ?></title> 
	<link rel="stylesheet" href="<?= RULROOT ?>/public/css/style.css"> 
</head>
<body> 
	
