<?php require_once APPROOT.'/views/inc/header.php'; ?> 
	<h1><?= $data['title'] ?></h1>  	
<?php require_once APPROOT.'/views/inc/footer.php'; ?>  