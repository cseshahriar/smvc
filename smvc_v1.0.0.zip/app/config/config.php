<?php
// DB Params
define('DB_HOST', 'localhost'); 
define('DB_USER', '_YOUR_USER'); 
define('DB_PASS', '_USER_PASS'); 
define('DB_NAME', '_DB_NAME');        

// App Root 
define('APPROOT' ,dirname(dirname(__FILE__)));  

// URL Root 
define('RULROOT', '_APP_URL');  

// Site Name
define('SITENAME', '_YOUR_SITE_NAME'); 

// Default time zone
date_default_timezone_set("Asia/Dhaka"); 

//default charset 
//header('Content-Type: text/html; charset=utf-8');