<script src="<?= RULROOT ?>/public/js/main.js"></script> 
</body>
</html>