<?php require_once APPROOT.'/views/inc/header.php'; ?> 	
<?php require_once APPROOT.'/views/inc/footer.php'; ?>   